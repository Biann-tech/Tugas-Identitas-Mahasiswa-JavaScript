const identitasMahasiswa = () => {
    const nama = "Fabian Mackenzie Purba";
    const nim = "25903460022";
    const prodi = "Teknologi Rekayasa Multimedia";
    const semester = 3;

    return `
    IDENTITAS MAHASISWA
    Nama          : ${nama}
    NIM           : ${nim}
    Program Studi : ${prodi}
    Semester      : ${semester}
    `;
};

console.log(identitasMahasiswa());
